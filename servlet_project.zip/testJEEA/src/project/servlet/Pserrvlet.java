package project.servlet;
import java.io.IOException;
import java.util.ArrayList;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import uqu.jeelab.dao.Content_Project;



public class Pserrvlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public Pserrvlet() {
    	super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	   this.getServletContext().getRequestDispatcher("/WEB-INF/form.jsp").forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Content_Project contentDAO= new Content_Project ();
		ArrayList result= null;
		try {
			result = contentDAO.getContent_Project();
			request.setAttribute("content_project", result);
			
		  this.getServletContext().getRequestDispatcher("/WEB-INF/list.jsp").forward(request, response);
		
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	
	}

}

