
	package uqu.jeelab.dao; 
	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.ResultSet;
	import java.sql.Statement;
	import java.util.ArrayList;
	import uqu.jeelab.model.*;
	
	
	public class Content_Project {
   
	private static String URL ="db4free.net:3306/coffeeproject";
	private static String user ="abrarbandar";
    private static String password ="A1234567";
    private Connection connect = null;
	private ResultSet resultSet = null;
	private ArrayList resList = new ArrayList();
	
	

	public ArrayList getContent_Project() throws Exception {   
		try { 
			
			connect = DriverManager.getConnection("jdbc:mysql://"+ URL , user, password);
	        
			Statement statement = connect.createStatement();
		    
			String sql= "SELECT* FROM content_project";
			resultSet = statement.executeQuery(sql);
			
		  while (resultSet.next()) { 
			 
			  String name_coffee= resultSet.getString("name_coffee");
			  String  type_coffee= resultSet.getString("type_coffee");
			  int ID = resultSet.getInt("ID");
		      resList.add(new content_C( name_coffee ,type_coffee , ID ));
		  } 
		   return resList; 
	    }  catch (Exception e) {   
	    	  throw e; 
	    } finally { 
	    	close();  
		}
	}
   
	private void close() {
			  try {  
				  if (resultSet != null) { 
					    resultSet.close();   
				  }
				  if (connect != null) {
					     connect.close();
                   } 
		     } catch (Exception e) { 
		           e.printStackTrace();   
		           
		     }
		}
  }
		 