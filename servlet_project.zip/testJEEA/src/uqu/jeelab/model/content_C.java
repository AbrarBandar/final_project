package uqu.jeelab.model;

public class content_C {

	private int ID;
	private String type_coffee;
	private String name_coffee;
	 
	
	public content_C (String Type_coffee ,String Name_coffee , int iD ) {
		ID          = iD;
		type_coffee = Type_coffee;
		name_coffee = Name_coffee;
	}

    public int getID() {
		return ID;
	}


	public void setID(int iD) {
		ID = iD;
	}

	public String getType_coffee() {
		return type_coffee;
	}

	public void setType_coffee(String type_coffee) {
		this.type_coffee = type_coffee;
	}

	public String getName_coffee() {
		return name_coffee;
	}

	public void setName_coffee(String name_coffee) {
		this.name_coffee = name_coffee;
	}
	
	
}
